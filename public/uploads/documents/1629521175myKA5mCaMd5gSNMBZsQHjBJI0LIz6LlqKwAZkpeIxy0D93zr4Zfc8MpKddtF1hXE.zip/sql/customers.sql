insert into customers (name, phone)
values
('Farangis','+992000000001'),
('Manizha','+992000000002'),
('Sayhuna','+992000000003'),
('Fanisa','+992000000004'),
('Habiba','+992000000005'),
('Shahnoza','+992000000006'),
('Zarina','+992000000007'),
('Abdusamad','+992000000008'),
('Qahhor','+992000000009'),
('Abdumalik','+992000000010')
on conflict 
do nothing
returning id;

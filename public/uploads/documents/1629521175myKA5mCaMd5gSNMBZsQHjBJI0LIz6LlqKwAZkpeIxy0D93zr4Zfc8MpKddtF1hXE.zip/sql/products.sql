select id,name, qty from products 
where
 qty>0 and active=true
 order by qty desc
 limit 10;


 
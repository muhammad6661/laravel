update customers set
 phone='+992000000011'
 where id=11
 returning id, name, active, created;